import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { useCreateNote, useUpdateNote, useDeleteNote, useAIProcess } from "@/hooks/use-notes";
import { Loader2, Trash2, Star, Sparkles, X, Check } from "lucide-react";
import { cn } from "@/lib/utils";
import type { Note } from "@shared/schema";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";

interface NoteEditorProps {
  note?: Note | null;
  isOpen: boolean;
  onClose: () => void;
}

export function NoteEditor({ note, isOpen, onClose }: NoteEditorProps) {
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [isFavorite, setIsFavorite] = useState(false);
  const [tags, setTags] = useState<string[]>([]);
  
  const createNote = useCreateNote();
  const updateNote = useUpdateNote();
  const deleteNote = useDeleteNote();
  const aiProcess = useAIProcess();

  useEffect(() => {
    if (note) {
      setTitle(note.title);
      setContent(note.content);
      setIsFavorite(note.isFavorite);
      setTags(note.tags || []);
    } else {
      setTitle("");
      setContent("");
      setIsFavorite(false);
      setTags([]);
    }
  }, [note, isOpen]);

  const handleSave = async () => {
    if (!title.trim() && !content.trim()) {
      onClose();
      return;
    }

    const finalTitle = title.trim() || "Untitled Note";

    try {
      if (note) {
        await updateNote.mutateAsync({
          id: note.id,
          title: finalTitle,
          content,
          isFavorite,
          tags
        });
      } else {
        await createNote.mutateAsync({
          title: finalTitle,
          content,
          isFavorite,
          tags
        });
      }
      onClose();
    } catch (e) {
      // Error handled in hook
    }
  };

  const handleDelete = async () => {
    if (note) {
      if (confirm("Are you sure you want to delete this note?")) {
        await deleteNote.mutateAsync(note.id);
        onClose();
      }
    }
  };

  const handleAIAction = async (action: 'summary' | 'improve' | 'tags') => {
    if (!content.trim()) return;
    
    try {
      const { result } = await aiProcess.mutateAsync({
        noteId: note?.id,
        content,
        action
      });

      if (action === 'tags' && Array.isArray(result)) {
        setTags([...new Set([...tags, ...result])]);
      } else if (typeof result === 'string') {
        if (action === 'improve') {
          setContent(result);
        } else if (action === 'summary') {
          // Append summary for now, could be a modal
          setContent(prev => prev + "\n\n--- AI Summary ---\n" + result);
        }
      }
    } catch (e) {
      // Error handled in hook
    }
  };

  const isSaving = createNote.isPending || updateNote.isPending;

  return (
    <Dialog open={isOpen} onOpenChange={(open) => {
      if (!open) handleSave();
    }}>
      <DialogContent className="max-w-3xl h-[85vh] p-0 gap-0 overflow-hidden flex flex-col bg-background/95 backdrop-blur-xl border-border shadow-2xl rounded-2xl">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-border/50">
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsFavorite(!isFavorite)}
              className={cn("hover:bg-yellow-500/10", isFavorite && "text-yellow-500")}
            >
              <Star className={cn("h-5 w-5", isFavorite && "fill-current")} />
            </Button>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm" className="gap-2 border-primary/20 bg-primary/5 hover:bg-primary/10 text-primary">
                  <Sparkles className="h-4 w-4" />
                  AI Tools
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start">
                <DropdownMenuItem onClick={() => handleAIAction('improve')}>
                  Improve Writing
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => handleAIAction('summary')}>
                  Generate Summary
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => handleAIAction('tags')}>
                  Auto-generate Tags
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            {aiProcess.isPending && (
              <span className="text-xs text-muted-foreground animate-pulse flex items-center gap-2">
                <Loader2 className="h-3 w-3 animate-spin" />
                AI is thinking...
              </span>
            )}
          </div>

          <div className="flex items-center gap-2">
            {note && (
              <Button
                variant="ghost"
                size="icon"
                onClick={handleDelete}
                className="text-muted-foreground hover:text-destructive hover:bg-destructive/10"
              >
                <Trash2 className="h-5 w-5" />
              </Button>
            )}
            <Button
              onClick={handleSave}
              disabled={isSaving}
              className="bg-primary hover:bg-primary/90 min-w-[100px]"
            >
              {isSaving ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <>
                  <Check className="h-4 w-4 mr-2" />
                  Save
                </>
              )}
            </Button>
          </div>
        </div>

        {/* Editor Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          <Input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Note Title"
            className="text-3xl font-display font-bold border-none px-0 shadow-none focus-visible:ring-0 placeholder:text-muted-foreground/40"
          />
          
          <div className="flex flex-wrap gap-2">
            {tags.map(tag => (
              <span key={tag} className="px-2 py-1 rounded-md bg-secondary text-secondary-foreground text-xs flex items-center gap-1 group">
                #{tag}
                <button 
                  onClick={() => setTags(tags.filter(t => t !== tag))}
                  className="opacity-0 group-hover:opacity-100 hover:text-destructive transition-opacity"
                >
                  <X className="h-3 w-3" />
                </button>
              </span>
            ))}
          </div>

          <Textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder="Start typing your thoughts..."
            className="min-h-[50vh] resize-none border-none px-0 shadow-none focus-visible:ring-0 text-lg leading-relaxed bg-transparent"
          />
        </div>
      </DialogContent>
    </Dialog>
  );
}
