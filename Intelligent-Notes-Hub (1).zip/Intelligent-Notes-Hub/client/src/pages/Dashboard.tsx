import { useState, useMemo } from "react";
import { useNotes } from "@/hooks/use-notes";
import { Sidebar } from "@/components/Sidebar";
import { NoteCard } from "@/components/NoteCard";
import { NoteEditor } from "@/components/NoteEditor";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Menu, Loader2, FileX } from "lucide-react";
import type { Note } from "@shared/schema";
import { AnimatePresence, motion } from "framer-motion";

export default function Dashboard() {
  const { data: notes, isLoading } = useNotes();
  const [searchQuery, setSearchQuery] = useState("");
  const [filter, setFilter] = useState<'all' | 'favorites'>('all');
  const [selectedNote, setSelectedNote] = useState<Note | null>(null);
  const [isEditorOpen, setIsEditorOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const filteredNotes = useMemo(() => {
    if (!notes) return [];
    
    return notes
      .filter(note => {
        const matchesSearch = 
          note.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          note.content.toLowerCase().includes(searchQuery.toLowerCase());
        const matchesFilter = filter === 'all' || (filter === 'favorites' && note.isFavorite);
        return matchesSearch && matchesFilter;
      })
      .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
  }, [notes, searchQuery, filter]);

  const handleCreateNew = () => {
    setSelectedNote(null);
    setIsEditorOpen(true);
    setIsMobileMenuOpen(false);
  };

  const handleNoteClick = (note: Note) => {
    setSelectedNote(note);
    setIsEditorOpen(true);
  };

  return (
    <div className="flex h-screen w-full bg-background overflow-hidden">
      {/* Desktop Sidebar */}
      <div className="hidden md:block w-64 lg:w-72 shrink-0">
        <Sidebar 
          onSearch={setSearchQuery} 
          onCreateNew={handleCreateNew}
          filter={filter}
          setFilter={setFilter}
        />
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col h-full overflow-hidden relative">
        {/* Mobile Header */}
        <div className="md:hidden flex items-center justify-between p-4 border-b border-border bg-background/80 backdrop-blur-sm z-10 sticky top-0">
          <h1 className="font-display font-bold text-xl">MindVault</h1>
          <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon">
                <Menu className="h-6 w-6" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="p-0 w-72">
              <Sidebar 
                onSearch={setSearchQuery} 
                onCreateNew={handleCreateNew}
                filter={filter}
                setFilter={(f) => {
                  setFilter(f);
                  setIsMobileMenuOpen(false);
                }}
              />
            </SheetContent>
          </Sheet>
        </div>

        <main className="flex-1 overflow-y-auto p-4 md:p-8">
          <div className="max-w-7xl mx-auto">
            {isLoading ? (
              <div className="flex flex-col items-center justify-center h-[50vh] gap-4">
                <Loader2 className="h-10 w-10 animate-spin text-primary" />
                <p className="text-muted-foreground animate-pulse">Loading your thoughts...</p>
              </div>
            ) : filteredNotes.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-[60vh] text-center gap-6">
                <div className="h-24 w-24 rounded-full bg-secondary/50 flex items-center justify-center">
                  <FileX className="h-10 w-10 text-muted-foreground" />
                </div>
                <div className="space-y-2">
                  <h3 className="text-xl font-bold font-display">No notes found</h3>
                  <p className="text-muted-foreground max-w-sm">
                    {searchQuery 
                      ? "Try adjusting your search terms." 
                      : "Create your first note to get started. Use AI to help you write!"}
                  </p>
                </div>
                {!searchQuery && (
                  <Button onClick={handleCreateNew} size="lg" className="bg-primary text-primary-foreground shadow-lg shadow-primary/25">
                    Create Note
                  </Button>
                )}
              </div>
            ) : (
              <div className="columns-1 sm:columns-2 lg:columns-3 xl:columns-4 gap-4 space-y-4 pb-20">
                <AnimatePresence mode="popLayout">
                  {filteredNotes.map((note) => (
                    <NoteCard 
                      key={note.id} 
                      note={note} 
                      onClick={() => handleNoteClick(note)} 
                    />
                  ))}
                </AnimatePresence>
              </div>
            )}
          </div>
        </main>
      </div>

      <NoteEditor 
        note={selectedNote}
        isOpen={isEditorOpen} 
        onClose={() => setIsEditorOpen(false)} 
      />
    </div>
  );
}
