import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { 
  LayoutGrid, 
  Plus, 
  Star, 
  LogOut, 
  Sparkles,
  Search
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useAuth } from "@/hooks/use-auth";

interface SidebarProps {
  onSearch: (query: string) => void;
  onCreateNew: () => void;
  filter: 'all' | 'favorites';
  setFilter: (filter: 'all' | 'favorites') => void;
}

export function Sidebar({ onSearch, onCreateNew, filter, setFilter }: SidebarProps) {
  const { user, logout } = useAuth();
  
  return (
    <div className="w-full h-full flex flex-col bg-sidebar border-r border-sidebar-border/50 text-sidebar-foreground p-4">
      <div className="flex items-center gap-3 px-2 mb-8 mt-2">
        <div className="h-8 w-8 rounded-lg bg-primary flex items-center justify-center text-primary-foreground">
          <Sparkles className="h-5 w-5" />
        </div>
        <h1 className="font-display font-bold text-xl tracking-tight">MindVault</h1>
      </div>

      <Button 
        onClick={onCreateNew}
        className="w-full mb-6 bg-primary hover:bg-primary/90 text-primary-foreground shadow-lg shadow-primary/20 hover:shadow-xl hover:shadow-primary/25 transition-all duration-300 group"
        size="lg"
      >
        <Plus className="mr-2 h-4 w-4 group-hover:rotate-90 transition-transform duration-300" />
        New Note
      </Button>

      <div className="relative mb-6">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input 
          placeholder="Search notes..." 
          className="pl-9 bg-background/50 border-sidebar-border focus:bg-background transition-colors"
          onChange={(e) => onSearch(e.target.value)}
        />
      </div>

      <nav className="flex-1 space-y-1">
        <button
          onClick={() => setFilter('all')}
          className={cn(
            "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-200",
            filter === 'all' 
              ? "bg-sidebar-accent text-sidebar-accent-foreground shadow-sm" 
              : "hover:bg-sidebar-accent/50 text-muted-foreground hover:text-foreground"
          )}
        >
          <LayoutGrid className="h-4 w-4" />
          All Notes
        </button>
        <button
          onClick={() => setFilter('favorites')}
          className={cn(
            "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-200",
            filter === 'favorites' 
              ? "bg-sidebar-accent text-sidebar-accent-foreground shadow-sm" 
              : "hover:bg-sidebar-accent/50 text-muted-foreground hover:text-foreground"
          )}
        >
          <Star className="h-4 w-4" />
          Favorites
        </button>
      </nav>

      <div className="mt-auto border-t border-sidebar-border pt-4">
        <div className="flex items-center justify-between px-2 mb-4">
          <div className="flex items-center gap-3 overflow-hidden">
            <div className="h-8 w-8 rounded-full bg-gradient-to-tr from-accent to-primary flex items-center justify-center text-white font-bold text-xs shrink-0">
              {user?.firstName?.[0] || user?.username?.[0] || 'U'}
            </div>
            <div className="flex flex-col truncate">
              <span className="text-sm font-medium truncate">{user?.firstName || 'User'}</span>
              <span className="text-xs text-muted-foreground truncate">{user?.email}</span>
            </div>
          </div>
        </div>
        <Button 
          variant="ghost" 
          className="w-full justify-start text-muted-foreground hover:text-destructive hover:bg-destructive/10"
          onClick={() => logout()}
        >
          <LogOut className="mr-2 h-4 w-4" />
          Log out
        </Button>
      </div>
    </div>
  );
}
