import { db } from "./db";
import { notes, type Note, type InsertNote, type UpdateNoteRequest } from "@shared/schema";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  // Notes
  getNotes(userId: string): Promise<Note[]>;
  getNote(id: number): Promise<Note | undefined>;
  createNote(userId: string, note: InsertNote): Promise<Note>;
  updateNote(id: number, updates: UpdateNoteRequest): Promise<Note | undefined>;
  deleteNote(id: number): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getNotes(userId: string): Promise<Note[]> {
    return await db.select()
      .from(notes)
      .where(eq(notes.userId, userId))
      .orderBy(desc(notes.updatedAt));
  }

  async getNote(id: number): Promise<Note | undefined> {
    const [note] = await db.select().from(notes).where(eq(notes.id, id));
    return note;
  }

  async createNote(userId: string, note: InsertNote): Promise<Note> {
    const [newNote] = await db
      .insert(notes)
      .values({ ...note, userId })
      .returning();
    return newNote;
  }

  async updateNote(id: number, updates: UpdateNoteRequest): Promise<Note | undefined> {
    const [updatedNote] = await db
      .update(notes)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(notes.id, id))
      .returning();
    return updatedNote;
  }

  async deleteNote(id: number): Promise<void> {
    await db.delete(notes).where(eq(notes.id, id));
  }
}

export const storage = new DatabaseStorage();
