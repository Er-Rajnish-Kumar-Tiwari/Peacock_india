import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import OpenAI from "openai";

// Import Integration Routes
import { setupAuth, registerAuthRoutes } from "./replit_integrations/auth";
import { registerChatRoutes } from "./replit_integrations/chat";

const openai = new OpenAI({
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
});

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // 1. Setup Auth
  await setupAuth(app);
  registerAuthRoutes(app);

  // 2. Setup Chat Integration (for generic chat if needed, though we act mainly on notes)
  registerChatRoutes(app);

  // 3. Notes API
  
  // List Notes
  app.get(api.notes.list.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const userId = (req.user as any).claims.sub;
    
    let notes = await storage.getNotes(userId);

    // Auto-seed for new users
    if (notes.length === 0) {
      await storage.createNote(userId, {
        title: "Welcome to AI Notes! 👋",
        content: "This is your first note. Try using the AI features to summarize or improve this text! You can also create new notes, organize them, and search through them.",
        isFavorite: true,
        tags: ["welcome", "getting-started"]
      });
      await storage.createNote(userId, {
        title: "Project Ideas 🚀",
        content: "- Build a personal website\n- Learn a new framework\n- Create a recipe app\n- Write a blog post about AI",
        isFavorite: false,
        tags: ["ideas", "planning"]
      });
      notes = await storage.getNotes(userId);
    }
    
    res.json(notes);
  });

  // Get Note
  app.get(api.notes.get.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    const id = parseInt(req.params.id);
    const note = await storage.getNote(id);
    
    if (!note) return res.sendStatus(404);
    
    // Check ownership
    const userId = (req.user as any).claims.sub;
    if (note.userId !== userId) return res.sendStatus(403);
    
    res.json(note);
  });

  // Create Note
  app.post(api.notes.create.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const userId = (req.user as any).claims.sub;

    try {
      const input = api.notes.create.input.parse(req.body);
      const note = await storage.createNote(userId, input);
      res.status(201).json(note);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      throw err;
    }
  });

  // Update Note
  app.put(api.notes.update.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const userId = (req.user as any).claims.sub;
    const id = parseInt(req.params.id);

    const existing = await storage.getNote(id);
    if (!existing) return res.sendStatus(404);
    if (existing.userId !== userId) return res.sendStatus(403);

    try {
      const input = api.notes.update.input.parse(req.body);
      const updated = await storage.updateNote(id, input);
      res.json(updated);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      throw err;
    }
  });

  // Delete Note
  app.delete(api.notes.delete.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const userId = (req.user as any).claims.sub;
    const id = parseInt(req.params.id);

    const existing = await storage.getNote(id);
    if (!existing) return res.sendStatus(404);
    if (existing.userId !== userId) return res.sendStatus(403);

    await storage.deleteNote(id);
    res.sendStatus(204);
  });

  // AI Process Route
  app.post(api.notes.aiProcess.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    try {
      const { action, content } = req.body;
      
      let prompt = "";
      if (action === "summary") {
        prompt = `Summarize the following note concisely:\n\n${content}`;
      } else if (action === "improve") {
        prompt = `Improve the grammar, clarity, and flow of the following note. Return ONLY the improved text, no explanations:\n\n${content}`;
      } else if (action === "tags") {
        prompt = `Generate up to 5 relevant tags for the following note. Return ONLY a JSON array of strings, e.g. ["tag1", "tag2"]:\n\n${content}`;
      }

      const response = await openai.chat.completions.create({
        model: "gpt-5.1",
        messages: [{ role: "user", content: prompt }],
        max_completion_tokens: 1024,
      });

      const resultText = response.choices[0]?.message?.content || "";

      if (action === "tags") {
        try {
          // Attempt to parse JSON
          // Handle markdown code blocks if present
          const cleanJson = resultText.replace(/```json\n?|\n?```/g, "").trim();
          const tags = JSON.parse(cleanJson);
          return res.json({ result: tags });
        } catch (e) {
          // Fallback if not valid JSON
          return res.json({ result: [] });
        }
      }

      res.json({ result: resultText });

    } catch (error) {
      console.error("AI Error:", error);
      res.status(500).json({ message: "Failed to process AI request" });
    }
  });

  return httpServer;
}
