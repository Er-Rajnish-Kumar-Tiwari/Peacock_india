## Packages
framer-motion | Smooth layout animations and page transitions
date-fns | Formatting dates for note timestamps
clsx | Utility for constructing className strings conditionally
tailwind-merge | Utility for merging Tailwind classes safely

## Notes
Using standard textarea for note input to ensure reliability for MVP.
AI features interact with /api/notes/ai-process endpoint.
Authentication uses Replit Auth (provided via /api/login, /api/logout).
Notes are fetched via TanStack Query and filtered locally for search.
