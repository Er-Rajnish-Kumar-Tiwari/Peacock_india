import { motion } from "framer-motion";
import { formatDistanceToNow } from "date-fns";
import { Star, Clock, Tag } from "lucide-react";
import { cn } from "@/lib/utils";
import type { Note } from "@shared/schema";

interface NoteCardProps {
  note: Note;
  onClick: () => void;
}

export function NoteCard({ note, onClick }: NoteCardProps) {
  // Strip HTML tags for preview if using rich text later, otherwise raw text
  const preview = note.content.slice(0, 150) + (note.content.length > 150 ? "..." : "");

  return (
    <motion.div
      layoutId={`note-${note.id}`}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
      whileHover={{ y: -4, transition: { duration: 0.2 } }}
      onClick={onClick}
      className={cn(
        "group cursor-pointer break-inside-avoid mb-4 rounded-xl p-5 border border-border bg-card text-card-foreground shadow-sm hover:shadow-md transition-all duration-300 relative overflow-hidden",
        note.isFavorite && "ring-2 ring-primary/20 border-primary/30"
      )}
    >
      {/* Decorative gradient blob */}
      <div className="absolute -right-12 -top-12 h-24 w-24 bg-gradient-to-br from-primary/10 to-accent/5 blur-2xl rounded-full group-hover:scale-150 transition-transform duration-500" />

      <div className="flex items-start justify-between gap-4 mb-3 relative z-10">
        <h3 className="font-display font-bold text-lg leading-tight group-hover:text-primary transition-colors duration-200">
          {note.title}
        </h3>
        {note.isFavorite && (
          <Star className="h-4 w-4 text-yellow-500 fill-yellow-500 shrink-0" />
        )}
      </div>

      <p className="text-muted-foreground text-sm leading-relaxed mb-4 line-clamp-4 relative z-10">
        {preview}
      </p>

      {note.tags && note.tags.length > 0 && (
        <div className="flex flex-wrap gap-2 mb-4 relative z-10">
          {note.tags.map((tag) => (
            <span 
              key={tag} 
              className="px-2 py-0.5 rounded-full bg-secondary text-secondary-foreground text-xs font-medium flex items-center gap-1"
            >
              <Tag className="h-3 w-3 opacity-50" />
              {tag}
            </span>
          ))}
        </div>
      )}

      <div className="flex items-center text-xs text-muted-foreground/60 gap-1 relative z-10">
        <Clock className="h-3 w-3" />
        {formatDistanceToNow(new Date(note.updatedAt), { addSuffix: true })}
      </div>
    </motion.div>
  );
}
